# Backend
## How to Run
```bash
# local
uvicorn main:app --reload
# container
docker build -t backend-img .
docker run -d --name backend -p 80:80 -v </path/ที่/เรา/ต้อง/การ/เอา/รูป/ไป/วาง>:/code/app/images backend-img
```