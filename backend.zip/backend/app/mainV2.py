import logging

from typing import List
from fastapi import FastAPI,File,UploadFile
from pydantic import BaseModel
from uuid import uuid4
from os import makedirs, path, getenv
from base64 import b64decode


# path สำหรับรันเป็น docker
root_path = "/code/app/images"
# path สำหรับรันบนเครื่องตัวเอง
# root_path = "/path/ที่/เรา/ต้อง/การ/เอา/รูป/ไป/วาง"

app = FastAPI()

#logging module
logging.basicConfig(filename='verification.log',level=logging.INFO)

class Images(BaseModel):
    face_img: List[str] = []
    id_card: List[str] = []

@app.get("/")
def read_root():
    return {"message": "backend root api", "transaction_id": uuid4().hex}

def create_folder(transaction_id: str):
    exec_path = path.join(root_path, transaction_id)
    try:
        input_path = path.join(exec_path, "input")
        makedirs(input_path, exist_ok=True)
        
        output_path = path.join(exec_path, "output")
        makedirs(output_path, exist_ok=True)
        return exec_path, None
    except OSError as error:
        return None, error

def decode_base64(images: List[str], img_dir_path: str):
    for image in images:
        img_path = path.join(img_dir_path, f"{uuid4().hex}.png")
        with open(img_path, "wb") as fh:
            fh.write(b64decode(image))

@app.post("/detection")
def detection(images: Images):
    # random id
    transaction_id = uuid4().hex

    # สร้าง folder เก็บรูป
    exec_path, err = create_folder(transaction_id)
    if err is not None:
        return {"message": f"Cannot create directory because: {err}", "transaction_id": transaction_id}
    
    # convert base64 เป็นรูป png
    decode_base64(images.face_img, path.join(exec_path, "input"))   # สำหรับหน้าปัจจุบัน
    decode_base64(images.id_card, path.join(exec_path, "output"))   # สำหรับรูปบัตรประชาชน

    # run model
    #model(exec_path)

    # log the verification status
    logging.info(f'Image verification status for transaction {transaction_id}: {status}')

    return {"is_valid": True, "transaction_id": transaction_id}
    #return {"is_valid": True, "transaction_id": transaction_id, "status":status}

